Capturing Reality RealityCapture 1.0.3.4658 RC [CLI Edition] *Fixed*

Instructions:
1. Install the software from setup.exe.
2. Place files from crack dir to install dir and overwrite existed files.
3. Double click registration.reg and confirm writting data to registry.

Fixed notes:
- Patching code improved, optimized and bugfixed. Now problems with application restarting/crashing after reconstruction/texturing was fixed. Now registration not reset during work if time was changed manually or by Windows sync.

